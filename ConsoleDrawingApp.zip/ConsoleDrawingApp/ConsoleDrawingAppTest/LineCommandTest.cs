﻿using ConsoleDrawingApp.Command;
using ConsoleDrawingApp.Model;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleDrawingApp.Test
{
    [TestClass]
    public class LineCommandTest
    {

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException), "should create a canvas first")]
        public void LineCommand_WithoutCanvas_ShouldPrint_Error()
        {
            //Arrange
            Canvas canvas = null;

            //Act
            var command = new LineCommand(canvas);

        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException), "missing command arguments")]
        public void Empty_Arguments_ShouldPrint_Error()
        {
            //Arrange
            List<string> canvas_Args = new List<string>() { "20", "10" };
            List<string> line_Args = null;
            var command = new CreateCommand();
            command.CommandValidation(canvas_Args);
            Canvas canvas = command.ExecuteCommand();
            var linecommand = new LineCommand(canvas);
            //Act
            linecommand.CommandValidation(line_Args);

        }


        [TestMethod]
        [ExpectedException(typeof(ArgumentException), "only accept 4 arguments: x1,x2,y1,y2")]
        public void Otherthan_Four_Argument_ShouldPrint_Error()
        {
            //Arrange
            List<string> canvas_Args = new List<string>() { "20", "10" };
            List<string> line_Args = new List<string>() { "-20", "10" };
            var command = new CreateCommand();
            command.CommandValidation(canvas_Args);
            Canvas canvas = command.ExecuteCommand();
            var linecommand = new LineCommand(canvas);
            //Act
            linecommand.CommandValidation(line_Args);

        }


        [TestMethod]
        [ExpectedException(typeof(ArgumentException), "arguments should be a positive int")]
        public void Neagtive_Argument_ShouldPrint_Error()
        {
            //Arrange
            List<string> vanvas_Args = new List<string>() { "20", "10" };
            List<string> line_Args = new List<string>() { "-20", "10" };
            var command = new CreateCommand();
            command.CommandValidation(vanvas_Args);
            Canvas canvas = command.ExecuteCommand();
            var linecommand = new LineCommand(canvas);
            //Act
            linecommand.CommandValidation(line_Args);

        }


        [TestMethod]
        [ExpectedException(typeof(ArgumentException), "point should be in the canvas")]
        public void Point_OutSide_Canvas_PrintError()
        {
            //Arrange
            List<string> canvas_Args = new List<string>() { "20", "10" };
            List<string> line_Args = new List<string>() { "2","4","22","11"};
            var command = new CreateCommand();
            command.CommandValidation(canvas_Args);
            Canvas canvas = command.ExecuteCommand();
            var linecommand = new LineCommand(canvas);
            //Act
            linecommand.CommandValidation(line_Args);


        }


        [TestMethod]
        public void Four_Valid_Argument_Should_Print()
        {
            //Arrange
            List<string> canvas_Args = new List<string>() { "20", "10" };
            List<string> line_Args = new List<string>() { "2", "4", "2", "8" };
            var command = new CreateCommand();
            command.CommandValidation(canvas_Args);
            Canvas canvas = command.ExecuteCommand();
            var linecommand = new LineCommand(canvas);
            //Act
            linecommand.CommandValidation(line_Args);
            var resut = command.ExecuteCommand();

            //Assert
            Assert.AreEqual(canvas.cells[2, 4], resut.cells[2, 8]);

        }
    }
}
