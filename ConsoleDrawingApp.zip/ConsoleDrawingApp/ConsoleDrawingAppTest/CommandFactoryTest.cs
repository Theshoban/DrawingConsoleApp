﻿using System;
using System.Collections.Generic;
using ConsoleDrawingApp.Command;
using ConsoleDrawingApp.Model;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConsoleDrawingApp.Test
{
    [TestClass]
    public class CommandFactoryTest
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException), "wrong command")]
        public void EmptyCommand_ShouldPrint_Error()
        {
            //Arrange
            Canvas canvas = null;
            List<string> input = null;

            //Act
            var command = CommandFactory.CreateCommandInstance(input, canvas);
        }


        [TestMethod]
        public void InvaliedCommand_ShouldPrint_Error()
        {
            //Arrange
            Canvas canvas = null;
            List<string> input = new List<string>() { "A" , "20" };
            try
            {
                //Act
                var command = CommandFactory.CreateCommandInstance(input, canvas);
                Assert.Fail("An exception should have been thrown");
            }
            catch(ArgumentException e)
            {
                //Assert 
                Assert.AreEqual($"Not supported command: {input[0]}", e.Message);
            }

           
        }

        [TestMethod]
        public void ValidCommand_Should_CreateCommand_Instance()
        {
            //Arrange
            Canvas canvas = null;
            List<string> input = new List<string>() { "C", "20" };
         
            //Act
            var command = CommandFactory.CreateCommandInstance(input, canvas);

            //Assert 
            Assert.IsInstanceOfType(new CreateCommand() { }, typeof(ICommand));



        }
    }
}
