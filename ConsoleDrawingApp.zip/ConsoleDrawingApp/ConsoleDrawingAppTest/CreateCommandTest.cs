﻿using ConsoleDrawingApp.Command;
using ConsoleDrawingApp.Model;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleDrawingApp.Test
{
    [TestClass]
    public class CreateCommandTest
    {

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException), "missing command arguments")]
        public void Empty_Arguments_ShouldPrint_Error()
        {
            //Arrange
            List<string> input = null;
            var command = new CreateCommand();
            //Act
            command.CommandValidation(input);

        }


        [TestMethod]
        [ExpectedException(typeof(ArgumentException), "only accept 2 arguments: width & height")]
        public void Otherthan_Two_Argument_ShouldPrint_Error()
        {
            //Arrange
            List<string> input = new List<string>() { "20" };
            var command = new CreateCommand();
            //Act
            command.CommandValidation(input);

        }


        [TestMethod]
        [ExpectedException(typeof(ArgumentException), "arguments should be a positive int")]
        public void Line_Neagtive_Argument_ShouldPrint_Error()
        {
            //Arrange
            List<string> input = new List<string>() {"-20", "10" };
            var command = new CreateCommand();
            //Act
            command.CommandValidation(input);

        }


        [TestMethod]
        public void Two_Positive_Argument_Should_Create_Canvas()
        {
            //Arrange
            var canvas = new Canvas(20, 10);
            List<string> input = new List<string>() { "20", "10" };
            var command = new CreateCommand();
            //Act
            command.CommandValidation(input);
            var resut = command.ExecuteCommand();

            //Assert
            Assert.AreEqual(canvas.cells[20, 10], resut.cells[1, 10]);

        }

       
    }
}
