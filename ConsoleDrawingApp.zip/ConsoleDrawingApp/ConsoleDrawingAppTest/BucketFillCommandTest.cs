﻿using ConsoleDrawingApp.Command;
using ConsoleDrawingApp.Model;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleDrawingApp.Test
{
    [TestClass]
    public class BucketFillCommandTest
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException), "should create a canvas first")]
        public void BucketFillCommand_WithoutCanvas_ShouldPrint_Error()
        {
            //Arrange
            Canvas canvas = null;

            //Act
            var command = new LineCommand(canvas);

        }

    


        [TestMethod]
        [ExpectedException(typeof(ArgumentException), "only accept 3 arguments: x,y,c")]
        public void Otherthan_Three_Argument_ShouldPrint_Error()
        {
            //Arrange
            List<string> canvas_Args = new List<string>() { "20", "10" };
            List<string> bucketFill_Args = new List<string>() { "-20", "10" };
            var command = new CreateCommand();
            command.CommandValidation(canvas_Args);
            Canvas canvas = command.ExecuteCommand();
            var bucketFill = new BucketFillCommand(canvas);
            //Act
            bucketFill.CommandValidation(bucketFill_Args);

        }


        [TestMethod]
        [ExpectedException(typeof(ArgumentException), "arguments should be a positive int")]
        public void  Two_Neagtive_Argument_ShouldPrint_Error()
        {
            //Arrange
            List<string> vanvas_Args = new List<string>() { "20", "10" };
            List<string> bucketFill_Args = new List<string>() { "-20", "10" };
            var command = new CreateCommand();
            command.CommandValidation(vanvas_Args);
            Canvas canvas = command.ExecuteCommand();
            var bucketFill = new BucketFillCommand(canvas);
            //Act
            bucketFill.CommandValidation(bucketFill_Args);

        }


        [TestMethod]
        [ExpectedException(typeof(ArgumentException), "point should be in the canvas")]
        public void BucketFill_Point_OutSide_Canvas_PrintError()
        {
            //Arrange
            List<string> canvas_Args = new List<string>() { "20", "10" };
            List<string> bucketFill_Args = new List<string>() { "22", "4", };
            var command = new CreateCommand();
            command.CommandValidation(canvas_Args);
            Canvas canvas = command.ExecuteCommand();
            var bucketFill = new BucketFillCommand(canvas);
            //Act
            bucketFill.CommandValidation(bucketFill_Args);

        }


        [TestMethod]
        public void Three_Valid_Argument_Should_Print()
        {
            //Arrange
            List<string> canvas_Args = new List<string>() { "20", "10" };
            List<string> bucketFill_Args = new List<string>() { "2", "4", "o" };
            var command = new CreateCommand();
            command.CommandValidation(canvas_Args);
            Canvas canvas = command.ExecuteCommand();
            var bucketFill = new BucketFillCommand(canvas);
            //Act
            bucketFill.CommandValidation(bucketFill_Args);
            var resut = bucketFill.ExecuteCommand();

            //Assert
            Assert.AreEqual(canvas.cells[2, 4], resut.cells[2, 4]);

        }
    }
}
