﻿using System;
using System.Collections.Generic;
using System.Linq;
using ConsoleDrawingApp.Model;

namespace ConsoleDrawingApp.Command
{
	public class RectangleCommand : BaseLineCommand
    {

		public RectangleCommand(Canvas canvas) : base(canvas)
		{
			
		}

        public override Canvas ExecuteCommand()
		{
            base.DrawLine(base._x1, base._x2, base._y1, base._y1);
            base.DrawLine(base._x1, base._x1 , base._y1, base._y2);
            base.DrawLine(base._x2, base._x2, base._y1, base._y2);
            return base.DrawLine(base._x1, base._x2, base._y2, base._y2);

		}
	}
}
