﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleDrawingApp.Model;

namespace ConsoleDrawingApp.Command
{
    public abstract class DrawingCommands : ICommand
    {
        public Canvas _canvas;
        public DrawingCommands(Canvas canvas)
        {
            _canvas = canvas ?? throw new ArgumentNullException("should create a canvas first");
        }

        public virtual void CommandValidation(List<string> cmd)
        {
            if (cmd == null || !cmd.Any())
                throw new ArgumentNullException("missing command arguments");
        }
        public abstract Canvas ExecuteCommand();
    }
}
