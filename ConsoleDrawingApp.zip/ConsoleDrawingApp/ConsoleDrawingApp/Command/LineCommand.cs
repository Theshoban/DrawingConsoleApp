﻿using System;
using System.Collections.Generic;
using System.Linq;
using ConsoleDrawingApp.Model;

namespace ConsoleDrawingApp.Command
{
	public class LineCommand : BaseLineCommand
	{

		public LineCommand(Canvas canvas) : base(canvas)
		{
			
		}

        public override Canvas ExecuteCommand()
        {
            return base.DrawLine(base._x1, base._x2, base._y1, base._y2);
        }
    }
}
