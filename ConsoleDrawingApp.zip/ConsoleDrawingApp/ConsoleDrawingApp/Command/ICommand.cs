﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleDrawingApp.Model;

namespace ConsoleDrawingApp.Command
{
	public interface ICommand
	{
		void CommandValidation(List<string> cmd);

		Canvas ExecuteCommand();
	}
}
